# @zenox/baileys

Fork [Baileys](https://github.com/WhiskeySockets/Baileys) (basis: `7.0.0-rc14`) dengan lapisan **Zenox**: multisesi, Redis + cache, auto reconnect cepat, dan auto save saat server mati. Semua API Baileys asli tetap ada.

```bash
npm i @zenox/baileys
npm i ioredis      # opsional, hanya kalau mau pakai Redis
```

## Mulai cepat

```ts
import { createZenox } from '@zenox/baileys'

const zenox = await createZenox({
  sessionDir: './sessions',
  redis: process.env.REDIS_URL,   // opsional: redis:// atau rediss:// (Upstash)
  fetchLatestVersion: true
})

// Dipanggil untuk SETIAP socket, termasuk yang dibuat ulang saat auto reconnect.
zenox.onSocket((sock, { session }) => {
  sock.ev.on('messages.upsert', ({ messages }) => { /* bot lu */ })
})

zenox.on('qr', ({ session, qr }) => console.log(qr))
zenox.on('pairing-code', ({ session, code }) => console.log(code))

const started = await zenox.startAll()                       // pulihkan semua sesi tersimpan
if (!started.length) await zenox.start('main', { pairingPhone: '62812xxxx' })
```

Contoh lengkap: `Example/zenox-example.ts`.

## Fitur

| Fitur | Cara kerja |
|---|---|
| **Auto reconnect cepat** | Retry pertama 200 ms, lalu x1.7 tiap gagal sampai maks 15 dtk (+-20% jitter). Kode 515 (restart setelah pairing) langsung tanpa jeda. Auth state, cache, dan activity dipakai ulang, jadi reconnect tidak membaca ulang disk/Redis. `onSocket` dipasang otomatis ke socket baru. |
| **Deteksi tidak ada internet** | Saat koneksi putus dengan tanda masalah jaringan (kode 408/428/503 atau tanpa kode), Zenox mengecek jaringan server (TCP ke `web.whatsapp.com`, `www.google.com`, `one.one.one.one`; satu saja yang menjawab = online). Kalau semuanya gagal, sesi masuk status `offline`: event `offline` dikirim sekali, **percobaan reconnect tidak dihitung** (jadi tidak kena `maxAttempts`), dan jaringan dicek ulang tiap 3 dtk. Begitu internet kembali, event `online` (berisi `offlineMs`) dikirim dan sesi langsung reconnect tanpa jeda. Semua sesi berbagi satu pengecekan, dan kejadian `offline`/`online` ikut tersimpan di catatan aktivitas. |
| **Multisesi** | `start('id')` sebanyak yang lu mau. Tiap sesi punya folder/key Redis, cache, dan reconnect sendiri. `startAll()` menyalakan semua sesi yang punya kredensial (jeda 300 ms antar sesi). |
| **Auto save kegiatan terakhir** | Tiap sesi menyimpan status, waktu buka/tutup, pesan terakhir, 50 event terakhir, dan `meta` buatan lu (`zenox.setMeta('main', {...})`). Saat start lagi, event `restored` memberi `previous` + `crashed` (true kalau run sebelumnya mati tanpa shutdown bersih). |
| **Cache + Redis** | Kunci sinyal dibaca dari memori (LRU), bukan disk. Cache group metadata, device list, retry counter, dan call offer; group/device juga di Redis (opsional). `sock.groupMetadata()` otomatis dicache dan di-invalidate oleh event grup. Redis mati = dianggap miss (circuit breaker), tidak pernah bikin error atau lambat. |
| **Auto save saat mati** | Tulis kunci ke memori dulu, flush batch tiap 1 dtk. `SIGINT/SIGTERM/SIGHUP`: simpan lalu keluar. `uncaughtException`: simpan lalu exit(1) seperti default Node. `process.exit()` / selesai normal: flush sinkron di event `exit`. `creds` selalu disimpan langsung (tidak menunggu interval). |
| **Respon lebih cepat** | Baca kunci dari memori, tulis tidak menunggu disk, group metadata di-cache, dan retry pesan terkirim dijawab dari memori. |

## Penyimpanan sesi

`sessionStore` (default `redis+file` kalau `redis` diisi, kalau tidak `file`):

- `file`: satu folder per sesi, nama file sama dengan `useMultiFileAuthState` (folder lama langsung kebaca). Tulis atomik (tmp + rename).
- `redis`: hanya Redis, tanpa disk.
- `redis+file`: baca selalu dari disk lokal (tanpa round trip), tulis ke disk lalu direplikasi ke Redis. Disk kosong/host baru: sesi dipulihkan dari Redis otomatis. Kalau Redis down, tulisan ditahan di backlog dan dikirim ulang di tulisan berikutnya.

Redis dipakai lewat pipeline (1 round trip per batch), cocok untuk Upstash.

## Pindah dari useMultiFileAuthState

```ts
// tanpa manager, tetap bisa:
import { useZenoxFileAuthState, makeWASocket } from '@zenox/baileys'
const auth = await useZenoxFileAuthState('baileys_auth_info')   // folder lama
const sock = makeWASocket({ auth: auth.state })
sock.ev.on('creds.update', auth.saveCreds)
// sebelum proses berhenti: await auth.close()
```

## Opsi `createZenox`

`sessionDir`, `redis`, `redisPrefix`, `sessionStore`, `storage` (backend sendiri), `socketConfig` (config Baileys per sesi/semua), `fetchLatestVersion`, `network` (`false` untuk mematikan, atau `{ hosts, timeoutMs, pollMs, cacheMs, check }`), `reconnect` (`initialDelayMs`, `maxDelayMs`, `factor`, `jitter`, `maxAttempts`, `reconnectOnReplaced`, `removeOnLogout`), `hooks` (`false` untuk mematikan, atau `{ signals, exitOnSignal, uncaughtException, unhandledRejection, shutdownTimeoutMs }`), `flushIntervalMs`, `maxPending`, `cacheSize`, `writeThrough` (simpan langsung, tanpa write-behind), `groupMetadataTtlMs`, `cacheGroupMetadata`, `redisCache`, `sentMessageCache`, `staggerMs`, `logger`.

## Event

`socket`, `qr`, `pairing-code`, `open`, `close`, `reconnecting`, `offline`, `online`, `give-up`, `logged-out`, `replaced`, `forbidden`, `restored`, `flush-error`, `shutdown`.

Method: `start`, `startAll`, `stop` (tetap login), `remove` (hapus data), `get`, `status`, `running`, `stored`, `activity`, `setMeta`, `flushAll`, `shutdown`.

## Deteksi internet: contoh dan batasan

```ts
zenox.on('offline', ({ session, since }) => console.log(`[${session}] tidak ada internet`))
zenox.on('online', ({ session, offlineMs }) => console.log(`[${session}] internet kembali setelah ${offlineMs} ms`))
zenox.status('main')       // 'offline' selama tidak ada internet
zenox.network?.online      // status terakhir yang diketahui (true/false), undefined sebelum pengecekan pertama
await zenox.network?.check() // cek sekarang
```

- Yang dicek adalah koneksi **dari server**. Kalau DNS mati, WhatsApp juga tidak bisa dijangkau, jadi dianggap offline.
- Kalau internet ada tapi hanya WhatsApp yang diblokir, status tetap online dan reconnect berjalan dengan backoff biasa.
- Pengecekan memakai koneksi TCP langsung. Kalau bot Anda lewat proxy (`agent` di `socketConfig`), atau jaringan memakai proxy transparan/captive portal yang menerima semua koneksi, hasilnya bisa meleset. Beri pengecekan sendiri: `network: { check: async () => ... }`, atau matikan dengan `network: false`.

## Batasan (jujur)

- `SIGKILL`, kill -9, mati listrik, atau OOM-kill tidak bisa ditangkap proses mana pun. Kunci yang belum di-flush (maks `flushIntervalMs`, default 1 dtk) bisa hilang; kalau itu tidak boleh, pakai `writeThrough: true` (lebih lambat) atau kecilkan `flushIntervalMs`.
- Kode 401 (logged out) menghapus sesi secara default karena kredensialnya sudah mati. Matikan dengan `reconnect: { removeOnLogout: false }`.
- Kode 440 (sesi diambil perangkat lain) dan 403 tidak di-reconnect supaya tidak rebutan/memperparah. Ubah lewat `reconnectOnReplaced`.
- Satu sesi = satu proses. Jangan jalankan dua proses dengan sesi yang sama.
- WhatsApp tidak mengizinkan library tidak resmi; akun bisa kena banned, apalagi kalau perilakunya seperti spam. Reconnect cepat tidak mengurangi risiko itu.
- Cache group metadata bisa basi paling lama `groupMetadataTtlMs` kalau WhatsApp tidak mengirim event perubahan.

## Test

```bash
npm run test:zenox   # 61 test: storage, deteksi internet, write-behind, Redis palsu, reconnect, dan proses anak yang di-SIGTERM/crash
```

## Publish ke npm

1. Daftar/login di npmjs.com dan buat **organization bernama `zenox`** (scope npm harus huruf kecil: `@zenox/baileys`, bukan `@Zenox`). Kalau nama `zenox` sudah dipakai orang lain, ganti `name` di `package.json` (misal `@namalu/baileys`).
2. `npm install && npm run build`
3. `npm pack --dry-run` (cek isi: `lib/`, `WAProto/`, `README.md`, `LICENSE`)
4. `npm login`, lalu `npm publish --access public`
5. Update berikutnya: naikkan `version` (`npm version patch`), build, publish lagi.

Pakai nama `baileys` lama tanpa ubah kode bot: `"baileys": "npm:@zenox/baileys@^1.0.0"` di `dependencies`.

## Lisensi

MIT. Kode dasar: Baileys (c) Rajeh Taher dan kontributor, file `LICENSE` asli wajib tetap ada di paket.
