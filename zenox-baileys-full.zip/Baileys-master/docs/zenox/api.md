# API Zenox

Untuk API Baileys dasar (`sock.sendMessage`, grup, event, ...) lihat [BAILEYS-API.md](../BAILEYS-API.md). Untuk sesi/Redis/reconnect lihat [ZENOX.md](../ZENOX.md). Halaman ini merangkum yang ditambahkan Zenox.

## `createZenox(options)`

Mengembalikan manager. Opsi (semuanya opsional):

| Opsi | Arti |
|---|---|
| `sessionDir` | folder sesi (default `./zenox-sessions`) |
| `redis`, `redisPrefix`, `sessionStore`, `storage`, `redisCache` | Redis dan penyimpanan sesi |
| `socketConfig` | opsi `makeWASocket` untuk semua sesi (objek atau fungsi per sesi) |
| `fetchLatestVersion` | ambil versi WhatsApp Web terbaru saat start |
| `reconnect`, `network`, `hooks` | auto reconnect, deteksi internet, simpan saat proses mati |
| `groupMetadataTtlMs` (5 mnt), `cacheGroupMetadata` (true) | cache data grup |
| `cacheMedia` (true), `mediaCacheSize` (300), `mediaCacheTtlMs` (1 jam) | cache upload media per sesi |
| `sentMessageCache`, `sentMessageTtlMs` | pesan terkirim disimpan untuk retry |
| `rich` | opsi pesan rich, atau `false` untuk mematikan |
| `warmup` | pemanasan, lihat di bawah; `false` untuk mematikan |
| `flushIntervalMs`, `maxPending`, `cacheSize`, `writeThrough`, `staggerMs`, `logger` | penyimpanan dan lainnya |

### `warmup`

```js
createZenox({
  warmup: {
    groups: true,            // muat semua grup ke cache setelah konek
    groupsDelayMs: 1500,     // tunggu sebentar supaya pesan pertama tidak terhambat
    media: true,             // ambil server upload + buka koneksi ke sana
    onMessage: true,         // pesan masuk: muat data grup / perangkat pengirim di latar belakang
    preconnect: ['https://nio-api-zenox.vercel.app']   // host lain yang dibuka koneksinya lebih dulu
  }
})
```

`groups: true` memanggil `groupFetchAllParticipating` sekali per koneksi, sehingga bot menerima event `groups.update` untuk semua grup (sama seperti saat WhatsApp mengirim tanda "dirty"). Kalau bot kamu memproses `groups.update` sebagai perubahan nyata, set `groups: false`; cache grup tetap terisi per grup saat pertama kali dipakai.

### Manager: event dan method

Event: `socket`, `qr`, `pairing-code`, `open`, `close`, `reconnecting`, `offline`, `online`, `give-up`, `logged-out`, `replaced`, `forbidden`, `restored`, `flush-error`, `shutdown`.
Method: `start`, `startAll`, `stop`, `remove`, `get`, `status`, `running`, `stored`, `activity`, `setMeta`, `flushAll`, `shutdown`, `onSocket`.

## `sock.react`

```ts
sock.react(message, emoji, options?)        // message = objek pesan dengan .key
sock.react(jid, key, emoji, options?)
// options: { wait?: boolean }  (default true)
// hasil:   { status: 'sent' } | { status: 'skipped', reason: 'same-emoji' | 'superseded' } | { status: 'queued' }
```

Aturan:
- satu reaksi pada satu pesan dikirim berurutan (⏳ tidak bisa mendarat sesudah ✅);
- reaksi yang masih antre digantikan reaksi yang lebih baru (hasilnya `skipped/superseded`);
- emoji yang sama dua kali tidak dikirim lagi (`skipped/same-emoji`);
- `wait: false` langsung kembali (`queued`), kegagalan hanya dicatat di log;
- emoji `''` menghapus reaksi.

## `sock.rich`

`send(jid, markdown, opts)`, `sendButtons(jid, input, opts)`, `action(label, name, data)`, `onAction(name, handler)`, `button.*`. Rincian tombol: [buttons.md](buttons.md). Rincian rich: `src/Zenox/rich/README.md`.

## Klien HTTP

Dipakai Baileys sendiri untuk unduh media, thumbnail link preview, dan upload media. Bisa dipakai juga untuk API kamu.

```js
import { createHttpClient, getSharedHttp, zenoxFetch, clearDnsCache, setFastHttpEnabled } from '@zenox-67/baileys'

const http = createHttpClient()                       // atau getSharedHttp() untuk klien milik Baileys
const res = await http.get('https://api.example.com/x', { timeoutMs: 8000, retries: 2 })
res.status; res.ok; res.headers; await res.json(); await res.text(); await res.buffer(); res.stream
await http.getJson(url)                               // lempar error kalau bukan 2xx
await http.postJson(url, { a: 1 })
await http.post(url, { body: 'teks' })                // string, Buffer, URLSearchParams, stream
await http.preconnect('https://api.example.com')      // buka koneksi lebih dulu
http.stats()                                          // { requests, reusedConnections, retries, dnsHits, dnsMisses }
http.destroy()
```

Opsi per request: `method`, `headers`, `body`, `json`, `timeoutMs` (sampai header, default 30000), `idleTimeoutMs` (diam saat menerima body, default 60000), `retries` (default 0), `retryDelayMs` (200, berlipat dua), `retryOn` (408/425/429/5xx), `retryNonIdempotent` (false), `maxRedirects` (5), `maxBytes`, `compress` (true), `signal`, `agent` (proxy sendiri).

Yang dilakukan klien ini dibanding `fetch` bawaan Node:
- koneksi disimpan 30 detik (bawaan Node 4 detik), jadi request beruntun ke host yang sama tidak mengulang DNS + TCP + TLS;
- hasil DNS diingat 60 detik; dibuang otomatis kalau koneksi gagal;
- koneksi lama yang ternyata sudah ditutup server dicoba ulang otomatis di koneksi baru;
- gzip/deflate/br didekompres otomatis, redirect diikuti, `Retry-After` dihormati.

### `zenoxFetch` untuk SDK

```js
import Nio from './vendor/nio.cjs'
import { zenoxFetch } from '@zenox-67/baileys'

const nio = new Nio({ baseUrl: 'https://nio-api-zenox.vercel.app', fetch: zenoxFetch })
```

`zenoxFetch` mengembalikan `Response` standar. Untuk input yang tidak didukung (FormData, Blob, stream web, objek `Request`, opsi `dispatcher`) ia meneruskan ke `fetch` bawaan, jadi aman dipasang di mana saja.

### Mematikan

`ZENOX_FAST_HTTP=0` (variabel lingkungan) atau `setFastHttpEnabled(false)`: unduhan Baileys kembali memakai `fetch` bawaan.

## Media: pengaturan

```js
import { configureFastMedia } from '@zenox-67/baileys'
configureFastMedia({ maxBytes: 8 * 1024 * 1024, cacheTtlMs: 30 * 60_000 })
```

- `maxBytes` (default 16 MB): batas media yang diproses di memori. Di atasnya memakai jalur file sementara seperti Baileys asli. `0` mematikan jalur memori.
- `cacheTtlMs` (default 1 jam): berapa lama upload yang sama dipakai ulang.
- Cache berada di `mediaCache` socket; di Zenox itu cache per sesi. Matikan dengan `createZenox({ cacheMedia: false })`.
- Uploader buatan sendiri (bukan bawaan) tetap menerima path file; jalur memori hanya dipakai bersama uploader bawaan.
