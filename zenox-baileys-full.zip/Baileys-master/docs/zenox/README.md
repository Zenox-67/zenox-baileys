# Dokumentasi Zenox Baileys

Mulai dari sini.

1. [Install](install.md): npm, GitHub, Termux.
2. [Cara pakai](usage.md): login, terima dan kirim pesan, media, reaksi.
3. [API](api.md): semua opsi dan method.
4. [Tombol](buttons.md): tombol dan tombol bintang.
5. [Pindah dari Baileys lain](migration.md).
6. [Performa](performance.md): apa yang dipercepat dan cara mengukurnya.
7. [Masalah umum](troubleshooting.md).
8. [Publish ke npm](publish-npm.md).

Referensi API Baileys dasar: [../BAILEYS-API.md](../BAILEYS-API.md). Detail sesi/Redis/reconnect: [../ZENOX.md](../ZENOX.md).
