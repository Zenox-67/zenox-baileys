# Masalah umum

| Gejala | Penyebab dan solusi |
|---|---|
| `npm i` dari GitHub lama sekali | normal: paket dibuild di perangkatmu. Tunggu, atau pakai versi npm kalau sudah dipublish |
| Build gagal di Termux dengan `TS2345 ... undefined` di `messages-media.ts` | sudah diperbaiki di versi ini (`?? 0`). Update paket; kalau dari GitHub, hapus `node_modules/@zenox-67` lalu install lagi |
| `Cannot find package '@zenox-67/baileys'` | belum terpasang atau namanya salah di `package.json`. Lihat [install.md](install.md) |
| Output install masih menampilkan `@whiskeysockets/baileys` | `package.json` bot lama. Ganti nama kunci dan import: [migration.md](migration.md) |
| `404 Not Found` saat `npm i @zenox-67/baileys` | paket belum dipublish ke npm: [publish-npm.md](publish-npm.md), atau pakai cara GitHub |
| `engines` / "requires Node.js 20+" | upgrade Node (`pkg install nodejs-lts`, atau nvm) |
| Tidak ada kode pairing | `pairingPhone` kosong atau salah format (pakai `628...` tanpa `+`). Hapus folder sesi yang rusak lalu coba lagi |
| Error 405 saat konek | pakai `createZenox({ fetchLatestVersion: true })` |
| Logout / "connection replaced" (440) | nomor itu dipakai di perangkat/proses lain. Satu sesi = satu proses |
| Bot diam setelah reconnect | event dipasang di luar `zenox.onSocket(...)`. Pindahkan ke dalamnya |
| Semua command diabaikan di Termux | prefix diambil dari variabel `PREFIX` milik Termux. Pakai nama lain (`BOT_PREFIX`) |
| `No image processing library available` | `npm i sharp` (atau `npm i jimp`) |
| Thumbnail video tidak ada | pasang `ffmpeg` |
| Media gagal dikirim padahal kecil | bandingkan dengan jalur lama: `ZENOX_FAST_HTTP=0` (unduh/HTTP) dan `configureFastMedia({ maxBytes: 0 })` (kirim media), lalu laporkan log lengkapnya |
| Gambar yang sama terkirim dengan gambar basi setelah lama | cache upload berlaku 1 jam (`configureFastMedia({ cacheTtlMs })`, atau `createZenox({ cacheMedia: false })`) |
| Event `groups.update` banjir saat start | itu pemanasan grup. Matikan: `warmup: { groups: false }` |
| Tombol tidak muncul | batasan klien WhatsApp, lihat [buttons.md](buttons.md); coba tanpa `image` |
| Akun diblokir/dibatasi | risiko memakai klien tidak resmi; hindari pesan massal dan perilaku mirip spam |

## Cara melaporkan masalah yang berguna

Sertakan: versi Node (`node -v`), perangkat (Termux/VPS), perintah yang dijalankan, **log error lengkap** (bukan potongan), dan ada tidaknya `sharp`/`ffmpeg`. Jangan sertakan isi folder sesi atau token. Laporan di [GitHub Issues](https://github.com/Zenox-67/zenox-baileys/issues).
