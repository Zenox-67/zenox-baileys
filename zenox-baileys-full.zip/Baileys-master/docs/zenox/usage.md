# Cara pakai yang benar

Contoh di sini memakai ESM (`import`). Simpan sebagai `bot.mjs` atau beri `"type": "module"` di `package.json`.

## 1. Bot paling sederhana

```js
import { createZenox } from '@zenox-67/baileys'

const zenox = await createZenox({
  sessionDir: './sessions',      // folder penyimpanan sesi
  fetchLatestVersion: true       // ambil versi WhatsApp Web terbaru (mencegah error 405)
})

zenox.on('qr', ({ qr }) => console.log('QR:', qr))
zenox.on('pairing-code', ({ code }) => console.log('Kode pairing:', code))
zenox.on('open', ({ session, reconnected }) => console.log(session, reconnected ? 'tersambung lagi' : 'tersambung'))

zenox.onSocket((sock) => {
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return
    for (const m of messages) {
      const text = m.message?.conversation ?? m.message?.extendedTextMessage?.text
      if (!text || m.key.fromMe) continue
      if (text === '.ping') await sock.sendMessage(m.key.remoteJid, { text: 'pong' }, { quoted: m })
    }
  })
})

const started = await zenox.startAll()
if (!started.length) await zenox.start('main', { pairingPhone: '628123456789' })
```

Penting:
- **Pasang event di dalam `zenox.onSocket(...)`**, bukan di luar. Fungsi itu dipanggil lagi untuk setiap socket baru setelah reconnect. Kalau dipasang di luar, bot berhenti merespons setelah reconnect pertama.
- `pairingPhone` memakai kode negara tanpa `+` atau spasi.
- `startAll()` memulihkan semua sesi yang pernah login. Kalau kosong (belum pernah login), baru `start('main', ...)`.

## 2. Login

**Kode pairing (disarankan untuk HP/Termux):** isi `pairingPhone`, tunggu event `pairing-code`, lalu di HP nomor bot: WhatsApp > Perangkat tertaut > Tautkan perangkat > **Tautkan dengan nomor telepon**, masukkan kode.

**QR:** jangan isi `pairingPhone`; event `qr` memberi teks QR (gambarkan dengan library QR, atau pakai `qrcode-terminal`).

Sesi tersimpan di `sessionDir/<id sesi>`. Jangan bagikan folder itu: isinya setara password akun. Jangan dua proses memakai sesi yang sama.

## 3. Menerima pesan

```js
sock.ev.on('messages.upsert', async ({ messages, type }) => {
  if (type !== 'notify') return          // 'append' = riwayat/pesan sendiri
  for (const m of messages) {
    const jid = m.key.remoteJid          // chat (grup berakhiran @g.us)
    const sender = m.key.participant || jid
    const text = m.message?.conversation ?? m.message?.extendedTextMessage?.text ?? m.message?.imageMessage?.caption
    // ...
  }
})
```

Pesan dari akun yang sama dengan bot punya `m.key.fromMe === true`. Kalau bot memakai nomormu sendiri dan kamu mengetik command dari nomor itu, jangan buang semua `fromMe`; cukup abaikan balasan bot sendiri (simpan id pesan yang dikirim bot).

## 4. Mengirim

```js
await sock.sendMessage(jid, { text: 'Halo' }, { quoted: m })
await sock.sendMessage(jid, { text: 'Halo @628123', mentions: ['628123@s.whatsapp.net'] })
await sock.sendMessage(jid, { image: buffer, caption: 'Foto' })                // Buffer
await sock.sendMessage(jid, { image: { url: 'https://…/a.jpg' }, caption: '' }) // URL
await sock.sendMessage(jid, { video: buffer, mimetype: 'video/mp4' })
await sock.sendMessage(jid, { sticker: webpBuffer })
await sock.sendMessage(jid, { audio: buffer, mimetype: 'audio/mp4', ptt: true }) // voice note
await sock.sendMessage(jid, { document: buffer, fileName: 'a.pdf', mimetype: 'application/pdf' })
```

Supaya pengiriman media cepat:
- Kirim **Buffer** (atau `{ url }` file/HTTP) dengan ukuran sampai 16 MB: lewat jalur memori tanpa file sementara.
- Gambar/stiker yang **sama** (menu, logo, banner) hanya diupload sekali selama satu jam; kirim berikutnya langsung memakai upload tadi.
- `{ stream }` dan file lebih besar dari 16 MB tetap lewat jalur streaming yang lama (aman untuk memori).

## 5. Reaksi emoji

```js
sock.react(m, '⏳', { wait: false })   // tidak menunggu, langsung lanjut
// ... kerjakan sesuatu ...
sock.react(m, '✅', { wait: false })   // kalau ⏳ belum sempat terkirim, hanya ✅ yang dikirim
await sock.react(m, '👍')              // menunggu sampai terkirim; melempar error kalau gagal
await sock.react(m, '')                // hapus reaksi
sock.react(jid, key, '✅')             // bentuk lain: jid + key pesan
```

## 6. Pesan rich dan tombol

```js
await sock.rich.send(jid, '# Judul\nIni **tebal** dan `kode`.\n| a | b |\n|:--|--:|\n| 1 | 2 |')

await sock.rich.sendButtons(jid, {
  body: 'Pilih salah satu',
  footer: 'Zenox',
  buttons: [
    sock.rich.button.quickReply('Ya', 'ya'),
    sock.rich.button.star('Favorit', 'fav'),
    sock.rich.button.url('Buka repo', 'https://github.com/Zenox-67/zenox-baileys'),
    sock.rich.button.copy('Salin kode', 'ABC123')
  ]
}, { quoted: m })
```

Detail dan batasannya: [buttons.md](buttons.md).

## 7. Request API tanpa lambat

```js
import { zenoxFetch, createHttpClient } from '@zenox-67/baileys'

const res = await zenoxFetch('https://api.example.com/data')      // pengganti fetch
const http = createHttpClient()
const data = await http.getJson('https://api.example.com/data', { retries: 2, timeoutMs: 8000 })
```

Lebih lengkap (termasuk memasang ke SDK yang menerima `fetch`): [api.md](api.md#klien-http).

## 8. Beberapa sesi (multi-nomor)

```js
await zenox.start('bot1', { pairingPhone: '6281...' })
await zenox.start('bot2', { pairingPhone: '6282...' })
zenox.onSocket((sock, { session }) => { /* session = 'bot1' atau 'bot2' */ })
```

## 9. Berhenti dengan benar

`Ctrl+C` / `SIGTERM` sudah menyimpan sesi otomatis. Dari kode: `await zenox.shutdown('selesai')`. `zenox.stop('bot1')` menghentikan satu sesi tapi tetap login; `zenox.remove('bot1')` menghapus datanya.

## 10. Tanpa createZenox (Baileys murni)

```js
import makeWASocket, { useMultiFileAuthState, DisconnectReason } from '@zenox-67/baileys'
```

Semua kode dari dokumentasi Baileys tetap berlaku ([BAILEYS-API.md](../BAILEYS-API.md)). Percepatan media dan HTTP aktif juga di sini. Yang hanya ada lewat `createZenox`: auto reconnect, cache grup yang terisi otomatis, pemanasan, `sock.react`, `sock.rich`.
