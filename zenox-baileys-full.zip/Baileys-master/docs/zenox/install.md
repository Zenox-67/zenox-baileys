# Install

Kebutuhan: **Node.js 20 atau lebih baru** (`node -v`), `git` kalau install dari GitHub.

## Cara 1: dari npm

```bash
npm i @zenox-67/baileys
```

Ini hanya jalan **setelah paket dipublish** ke npm. Kalau perintah menjawab `404 Not Found`, paketnya belum ada di npm: pakai cara 2 atau ikuti [publish-npm.md](publish-npm.md).

## Cara 2: dari GitHub (bisa dipakai sekarang)

```bash
npm i @zenox-67/baileys@github:Zenox-67/zenox-baileys
```

Bentuk `nama@github:pemilik/repo` membuat paket terpasang dengan nama `@zenox-67/baileys`. Di `package.json` bot hasilnya:

```json
"dependencies": {
  "@zenox-67/baileys": "github:Zenox-67/zenox-baileys"
}
```

Install dari GitHub membuild paketnya di HP/server kamu (script `prepare`), jadi pertama kali bisa beberapa menit. Versi tertentu: `github:Zenox-67/zenox-baileys#v1.1.0` (tag) atau `#<commit>`.

## Pakai di kode

```js
import { createZenox } from '@zenox-67/baileys'
// atau, API Baileys biasa:
import makeWASocket, { useMultiFileAuthState } from '@zenox-67/baileys'
```

Proyek CommonJS (`require`) tidak bisa meng-`require` paket ESM langsung; pakai `const { createZenox } = await import('@zenox-67/baileys')` atau jadikan proyekmu ESM (`"type": "module"` di `package.json`).

## Opsional (disarankan)

```bash
npm i sharp        # thumbnail gambar cepat. Kalau gagal dipasang: npm i jimp
npm i ioredis      # hanya kalau pakai Redis
npm i link-preview-js   # preview link
```

Untuk thumbnail video pasang `ffmpeg` (`pkg install ffmpeg` di Termux, `apt install ffmpeg` di Linux). Tanpa itu video tetap terkirim, hanya tanpa thumbnail.

## Termux (Android)

```bash
pkg update && pkg upgrade
pkg install nodejs-lts git ffmpeg
node -v                       # harus v20 atau lebih
mkdir bot && cd bot && npm init -y
npm i @zenox-67/baileys@github:Zenox-67/zenox-baileys
```

Catatan Termux:
- Variabel lingkungan `PREFIX` sudah dipakai Termux (isinya `/data/data/com.termux/files/usr`). Jangan pakai nama `PREFIX` untuk prefix command bot; pakai `BOT_PREFIX`.
- Kalau `npm i sharp` gagal, pakai `npm i jimp` (lebih lambat tapi jalan).
- Kalau build gagal, kirim log error lengkapnya; jangan hanya baris terakhir.

## Update

```bash
npm update @zenox-67/baileys                       # dari npm
npm i @zenox-67/baileys@github:Zenox-67/zenox-baileys   # dari GitHub, ambil commit terbaru
```

Kalau npm masih memakai versi lama dari GitHub: hapus `node_modules/@zenox-67` dan baris paket itu di `package-lock.json`, lalu install lagi.

## Cek terpasang benar

```bash
node -e "import('@zenox-67/baileys').then(m => console.log(typeof m.createZenox, typeof m.default))"
# function function
```

Nama paket yang tampil saat `npm ls` harus `@zenox-67/baileys`. Kalau masih muncul `@whiskeysockets/baileys`, itu dari `package.json` bot lamamu: lihat [migration.md](migration.md).
