# Memasukkan paket ke npm

Tujuan: orang (dan bot kamu) bisa `npm i @zenox-67/baileys` tanpa tahu GitHub.

> Status: paket **belum** dipublish. Publish membutuhkan akun npm milikmu; tidak bisa dilakukan dari luar akunmu. Langkah di bawah adalah semua yang perlu kamu lakukan, sekali saja.

## 1. Siapkan akun dan scope

Scope npm harus huruf kecil: `@zenox-67` (bukan `@Zenox-67`).

1. Daftar di https://www.npmjs.com (aktifkan 2FA).
2. Scope `@zenox-67` harus dimiliki akunmu. Dua cara:
   - username npm-mu **`zenox-67`**, atau
   - buat **organization** bernama `zenox-67` (https://www.npmjs.com/org/create, paket publik gratis).
3. Cek namanya masih bebas: `npm view @zenox-67/baileys`. `404` = bebas.

Kalau `zenox-67` tidak bisa dipakai, ganti `name` di `package.json` (misalnya `@namakamu/baileys`) dan sesuaikan semua dokumentasi.

## 2. Publish dari HP/PC (paling sederhana)

```bash
git clone https://github.com/Zenox-67/zenox-baileys && cd zenox-baileys
npm install
npm run build
npm run test:zenox        # opsional tapi disarankan
npm pack --dry-run        # cek isi: lib/, WAProto/, docs/, README.md, LICENSE
npm login
npm publish --access public          # kalau 2FA: tambahkan --otp=123456
```

Cek hasilnya: `npm view @zenox-67/baileys version`, lalu di folder lain `npm i @zenox-67/baileys`.

## 3. Publish otomatis dari GitHub (opsional)

Setiap kali kamu membuat **Release** di GitHub, paket terbit sendiri (dengan label provenance).

1. Di npm: **Access Tokens > Generate New Token > Granular**: izin *Read and write* untuk paket `@zenox-67/baileys` (atau scope `@zenox-67`), centang bypass 2FA untuk otomasi. Salin tokennya.
2. Di GitHub repo: **Settings > Secrets and variables > Actions > New repository secret**, nama `NPM_TOKEN`, isi token tadi.
3. Buat file workflow **lewat web GitHub** (Add file > Create new file): nama `.github/workflows/publish.yml`, isi salin dari [workflows/publish.yml](workflows/publish.yml). Harus manual: token bawaan GitHub Actions tidak diizinkan mendorong file di `.github/workflows`, jadi workflow ekstrak zip tidak bisa membuatnya.
4. Naikkan versi: `npm version patch` (atau ubah `version` di `package.json`), push, lalu **Releases > Draft a new release**, tag `v1.1.1` (harus sama dengan `version`), publish. Tab **Actions** menunjukkan prosesnya.
5. Coba tanpa publish: Actions > "Publish ke npm" > Run workflow dengan `dry_run = true`.

## 4. Update berikutnya

```bash
npm version patch        # 1.1.0 -> 1.1.1 (minor / major untuk perubahan lebih besar)
git push --follow-tags
# lalu publish (cara 2) atau buat Release (cara 3)
```

Versi yang sudah terbit tidak bisa ditimpa; selalu naikkan nomor.

## 5. Setelah terbit

- Di bot: `npm i @zenox-67/baileys`, ganti import ([migration.md](migration.md)).
- Pemakai yang tidak mau menunggu npm tetap bisa `npm i @zenox-67/baileys@github:Zenox-67/zenox-baileys`.
- Salah publish? `npm deprecate @zenox-67/baileys@1.1.0 "pesan"`; `npm unpublish` hanya diizinkan dalam 72 jam pertama dan jika belum ada paket lain yang bergantung.

## Yang masuk ke paket

`package.json > files`: `lib/` (hasil build), `WAProto/`, `docs/zenox/`, `docs/ZENOX.md`, `engine-requirements.js`, ditambah `README.md`, `LICENSE`, `package.json` otomatis. Build (`prepare`) berjalan saat `npm publish`, jadi `lib/` selalu segar.

`LICENSE` Baileys asli harus tetap ada di paket (syarat lisensi MIT).
