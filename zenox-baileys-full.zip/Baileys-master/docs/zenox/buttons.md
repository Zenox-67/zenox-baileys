# Tombol

```js
const rich = sock.rich
await rich.sendButtons(jid, {
  body: 'Teks pesan',
  footer: 'Footer',
  title: 'Judul (opsional)',
  buttons: [
    rich.button.quickReply('Ya', 'ya'),
    rich.button.star('Favorit', 'fav'),
    rich.button.url('Buka', 'https://example.com'),
    rich.button.copy('Salin', 'KODE'),
    rich.button.call('Telepon', '+628123456789'),
    rich.button.select('Pilih', [{ title: 'Menu', rows: [{ title: 'A', id: 'a' }, { title: 'B', id: 'b' }] }])
  ]
}, { quoted: m })
```

Membaca tap: pesan balasan memuat id tombol; `extractButtonId(m.message)` mengembalikannya. Atau pakai tombol aplikasi:

```js
rich.onAction('hapus', async ({ jid, data }) => { /* ... */ })
const tombol = await rich.action('Hapus', 'hapus', { id: 5 })   // masuk ke buttons
```

## Tombol bintang

`rich.button.star('Favorit', id)` adalah quick reply dengan karakter teks **★** (U+2605, ditambah penanda tampilan teks U+FE0E) di depan label. Itu karakter font, **bukan emoji** ⭐.

## Apakah ikon bisa diganti SVG?

**Di dalam tombol: tidak bisa.** Gambar kecil di sebelah tombol WhatsApp (panah balas, tautan, salin, telepon) ditentukan aplikasi WhatsApp dari jenis tombolnya. Bot hanya mengirim nama jenis dan teks; tidak ada field untuk gambar/ikon di tombol, jadi SVG tidak bisa ditempel di situ oleh library mana pun.

**Yang bisa:** menggambar bintang dari SVG dan menampilkannya sebagai gambar di atas pesan tombol.

```js
import { starPng } from '@zenox-67/baileys'      // butuh: npm i sharp

await sock.rich.sendButtons(jid, {
  image: await starPng({ color: '#F5B301', size: 256 }),   // PNG dari SVG bintang
  body: 'Suka bot ini?',
  buttons: [sock.rich.button.star('Suka', 'suka')]
}, { quoted: m })
```

Fungsi lain: `starSvg(opts)` (teks SVG), `svgToPng(svg, { size })` (SVG apa pun menjadi PNG), `STAR_GLYPH`.

Batasan jujur: gambar di header pesan native-flow dibuat sesuai struktur pesan WhatsApp, tetapi **belum diuji langsung di semua versi aplikasi**; klien tertentu bisa menolak menampilkan tombolnya. Kalau tombol hilang saat memakai `image`, kirim tanpa `image` atau kirim gambarnya sebagai pesan terpisah. Tombol native-flow sendiri juga bergantung pada klien (lihat `src/Zenox/rich/README.md`).
