# Pindah dari `@whiskeysockets/baileys` (atau `baileys`)

API-nya sama, hanya nama paket yang berubah.

## 1. Ganti paket

```bash
npm uninstall @whiskeysockets/baileys baileys
npm i @zenox-67/baileys@github:Zenox-67/zenox-baileys     # atau: npm i @zenox-67/baileys
```

## 2. Ganti semua import

Linux / Termux:

```bash
grep -rl --exclude-dir=node_modules -e "@whiskeysockets/baileys" . | xargs sed -i 's#@whiskeysockets/baileys#@zenox-67/baileys#g'
```

Cek hasilnya: `grep -rn --exclude-dir=node_modules "whiskeysockets" .` tidak boleh menampilkan apa-apa selain komentar.

Kalau `package.json` bot masih punya baris `"@whiskeysockets/baileys": "github:Zenox-67/zenox-baileys"`, ganti nama kuncinya menjadi `"@zenox-67/baileys"`. Nama di kunci itulah yang tampil di output install; isi repo-nya sudah bernama `@zenox-67/baileys`.

## 3. Sesi lama tetap bisa dipakai

Folder dari `useMultiFileAuthState('folder')` bisa dibuka apa adanya:

```js
import makeWASocket, { useZenoxFileAuthState } from '@zenox-67/baileys'
const auth = await useZenoxFileAuthState('baileys_auth_info')
const sock = makeWASocket({ auth: auth.state })
sock.ev.on('creds.update', auth.saveCreds)
```


## 4. Yang boleh tetap sama

`makeWASocket`, `useMultiFileAuthState`, `DisconnectReason`, `downloadMediaMessage`, `sock.sendMessage`, semua event `sock.ev`. Tidak ada yang dihapus.

## 5. Ambil percepatannya (opsional)

- Ganti `makeWASocket(...)` + kode reconnect buatan sendiri dengan `createZenox(...)`: cache grup, pemanasan, dan reconnect sudah jadi.
- Ganti `sock.sendMessage(jid, { react: ... })` dengan `sock.react(m, '✅')`.
- Pasang `zenoxFetch` ke SDK/API yang kamu pakai (lihat [api.md](api.md#klien-http)).

## Alias nama lama (tidak disarankan)

Kalau ada library lain yang meng-`import 'baileys'` dan tidak bisa diubah, npm bisa memberi nama alias:

```json
"baileys": "npm:@zenox-67/baileys@^1.1.0"
```

Dengan cara ini nama `baileys` muncul di output install. Untuk bot sendiri, ganti import seperti langkah 2.
