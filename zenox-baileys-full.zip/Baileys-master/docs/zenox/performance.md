# Performa

Halaman ini menjelaskan apa yang dipercepat, kenapa, dan apa yang **tidak** bisa dipercepat. Angka milidetik sengaja tidak dijanjikan: hasilnya bergantung pada jaringan, lokasi server, HP, dan WhatsApp. Cara mengukur ada di bawah.

## Kenapa bot terasa lambat di awal lalu makin cepat

Dua sebab, keduanya sekarang ditangani:

1. **Data grup.** Setiap kali Baileys mengirim ke grup ia butuh daftar anggota. Kalau tidak ada di cache, ia bertanya ke server WhatsApp (satu kali bolak-balik jaringan) **di setiap pengiriman**, karena jawabannya tidak pernah disimpan. Di Zenox cache itu kini terisi otomatis pada pengiriman pertama, dan dimuat lebih dulu saat konek (`warmup.groups`) serta saat pesan dari grup itu masuk.
2. **Koneksi dingin.** Upload media dan request API pertama membuka koneksi baru (DNS + TCP + TLS). Sekarang koneksi ke server media dibuka saat konek (`warmup.media`), dan koneksi ke API kamu bisa dibuka lebih dulu (`warmup.preconnect`, `http.preconnect(url)`).

## Daftar percepatan

| Area | Perubahan | Berlaku untuk |
|---|---|---|
| Kirim ke grup | cache data grup terisi otomatis, permintaan paralel digabung | `createZenox` |
| Pesan masuk | data grup / daftar perangkat pengirim dimuat di latar belakang selagi bot memproses | `createZenox` |
| Reaksi | `sock.react`: berurutan, reaksi basi dibuang, `wait:false` tidak menahan kode | `createZenox` |
| Kirim media | enkripsi di memori, tanpa tulis/baca file sementara, upload dari memori | semua pemakaian (media ≤ 16 MB, uploader bawaan) |
| Media sama berulang | upload sekali, kirim berikutnya langsung pakai (kunci: hash isi) | semua (butuh `mediaCache`; Zenox menyalakannya) |
| Proses media | thumbnail dan baca ukuran gambar berjalan bersamaan; thumbnail dari memori | semua |
| Unduh media | koneksi keep-alive + cache DNS | semua |
| Upload media | pool koneksi keep-alive + cache DNS (kecuali kamu mengisi `fetchAgent` sendiri) | semua |
| HTTP / API | `zenoxFetch` / `createHttpClient` | kode bot kamu |

## Yang tidak bisa dipercepat

- **Waktu jaringan ke WhatsApp.** Pesan tetap harus dienkripsi dan dikirim lewat koneksi websocket; ping HP/server ke WhatsApp menentukan sisanya. Server yang dekat (Singapura/Jakarta) lebih cepat daripada jauh.
- **Pesan pertama ke kontak baru.** Perangkat dan sesi enkripsinya harus diambil sekali.
- **Kecepatan API pihak lain.** Yang bisa dihemat hanya DNS/TCP/TLS dan retry; bukan waktu proses server mereka.
- **Ukuran media.** Upload 10 MB tetap memakan waktu sesuai bandwidth upload.
- **Ikon tombol.** Bukan soal kecepatan; lihat [buttons.md](buttons.md).

## Tips pemakaian

- Pasang event di `zenox.onSocket`, dan jangan `await` hal yang tidak perlu sebelum membalas. Reaksi ⏳ jangan ditunggu: `sock.react(m, '⏳', { wait: false })`.
- Jalankan panggilan API dan reaksi paralel (`Promise.all` atau `void`), bukan berurutan.
- Gambar menu/banner: kirim sebagai **Buffer yang sama** (baca file sekali saat start, simpan di variabel). Pengiriman kedua dan seterusnya melewati enkripsi dan upload.
- Pasang `sharp` untuk thumbnail; `jimp` jauh lebih lambat.
- Panggilan API yang sering: pakai `zenoxFetch`/`createHttpClient` dan isi `warmup.preconnect`.
- Jangan membuat socket baru tiap kali; satu proses, satu sesi, biarkan `createZenox` yang menyambung ulang.
- Redis tidak membuat pengiriman lebih cepat; ia berguna untuk pemulihan sesi dan cache lintas restart. Tanpa Redis juga cepat.

## Cara mengukur

Ukur waktu di dalam bot, jangan dengan perasaan:

```js
const t0 = performance.now()
await sock.sendMessage(jid, { text: 'tes' })
console.log('kirim', Math.round(performance.now() - t0), 'ms')
```

Bandingkan **pengiriman ke-1 dan ke-5** ke grup yang sama, dengan `warmup: false` dan dengan default, untuk melihat efek cache grup. Untuk HTTP: `http.stats()` menunjukkan `reusedConnections` (berapa request memakai koneksi lama) dan `dnsHits`.

Waktu "pesan masuk sampai balasan terkirim" yang kamu lihat di WhatsApp ikut menghitung jaringan HP pengirim dan server WhatsApp, jadi tidak sama dengan waktu di dalam bot.

## Apa yang sudah diuji

- Enkripsi memori menghasilkan byte yang sama persis dengan jalur streaming lama (tes membandingkan keduanya, ukuran 0 sampai 3 MB) dan bisa didekripsi balik dengan MAC valid.
- Klien HTTP: koneksi dipakai ulang, retry, redirect, gzip, batas ukuran, timeout, dan pemulihan dari koneksi yang ditutup server, diuji dengan server lokal.
- Cache grup, pemanasan, prefetch, urutan reaksi, dan pembuatan PNG bintang dari SVG diuji.

**Belum diuji:** pengiriman nyata ke WhatsApp dengan akun sungguhan (tidak ada akun di lingkungan pengembangan), jadi besar selisih kecepatan pada bot kamu belum terukur. Laporkan angka sebelum/sesudahmu kalau ada yang janggal.
